# Program kivy0
# Explica functiile kivy
# Ion Studentul - 1/26/13

from kivy.app import App

class PrimulProgramKivy(App):
    pass

PrimulProgramKivy().run()