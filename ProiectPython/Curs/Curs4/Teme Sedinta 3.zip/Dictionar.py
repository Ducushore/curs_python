#Creati un dictionar cu elementele:
#1-"Unu"
#2-"Doi Doi"
#3-"Trei Trei Trei"

#Printati fiecare pereche de tip cheie valoare din dictionar printr-un for.

#Solicitati userului sa introduca text de la tastatura. Acest text devine valoarea unei noi
#intrari in dictionar ce va avea cheia 4.
#Printati fiecare pereche de tip cheie valoare din dictionar printr-un for.

#Stergeti intrarea ce are cheia cu numarul 2. Printati fiecare pereche de tip cheie valoare din dictionar printr-un for.

dictionar={1:"unu",2:"doi doi",3:"trei trei trei"}

for cheie in dictionar:
        print cheie,"=> " , dictionar[cheie]

dictionar[4]=raw_input("Introdu un nou element: \n")
print "\n"
for cheie in dictionar:
        print cheie,"=> " , dictionar[cheie]

del dictionar[2]

print "\n"
for cheie in dictionar:
        print cheie,"=> " , dictionar[cheie]
