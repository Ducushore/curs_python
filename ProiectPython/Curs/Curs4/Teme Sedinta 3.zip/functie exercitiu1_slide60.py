# Testeaza cunostinte functii
# Cum realizam o functie
# Ion Studentul

#Creati o functie care sa calculeze si sa returneze operatia matematica
#de mai jos exclusiv pentru 3 numere.
#Daca nu sunt numere returnati sirul de caractere "Dati va rog 3 numere":
#                               [a(a+3)/b]*c


def matem(a,b,c,*d):
    """cere 3 parametrii, returneaza [a(a+3)/b]*c"""
    if((type(a)==type(2)) and (type(b)==type(2)) and (type(c)==type(2))):
        x = (a*(a+3)/b)*c
    else:
        x = "Dati va rog 3 numere"
    for e in d:
        e_s= str(e)
        if (e_s.isdigit()):
            x=+e
            
    return x

print matem(1,2,3)
print matem("1","2","3")
print matem(1,2,3,4)
