# Program Tema Sedinta3
# Demonstreaza utilizarea obiectelor
# Ion Stundentul - 1/26/13


# Creati o clasa ce va reprezenta un catalog:
# La initializare trebuie sa oferim doi parametrii de intrare nume si prenume
# Avem o metoda care afiseaza absente implementat cu __str__
# Avem o metoda care incrementeaza cu 1 nr. de absente
# Avem o metoda care sterge un nr. (exclusiv un numar - verifica)  de absente dat (pentru cazurile in care avem o scutire medical) fara a deveni negativ
# Creati 1 student numit  Ion Roata
# Modificati argumentul absente sa fie incrementat de 3 ori prin metoda creata
# Stergeti doua absente prin metoda specificata
# Creati al doilea student numit George Cerc
# Modificati argumentul absente sa fie incrementat de 4 ori prin metoda creata
# Stergeti doua absente prin metoda specificata
# Afisati absentele fiecarui student


class Catalog(object):
    """catalog absente"""
    
    def __init__(self,Nume,Prenume):
        """initializeaza argumente"""
        self.Nume = Nume
        self.Prenume  = Prenume
        self.absente = 0

    def __str__(self):
        """afiseaza nr. de absente"""        
        return "Numarul de absente al studentului "+ str(self.Nume)+" "+str(self.Prenume)+" este "+str(self.absente)+"\n"

    def IncrAbs(self):
        """Incrementeaza absente"""
        self.absente+=1
        
    def StergeAbs(self,nr):
        """Scade din nr actual un numar de absente"""
        if (type(nr)==type(int())):
            if (self.absente<nr):
                self.absente = 0
            else:
                self.absente = self.absente - nr
        else:
            print "Nu ai dat un numar\n"

#MAIN

#student1
std1=Catalog("Ion", "Roata")
std1.IncrAbs() ; std1.IncrAbs() ; std1.IncrAbs()
print "Cu scop de verificare! nu a fost solicitat in cerinta\n",std1

std1.StergeAbs("2")
print "Cu scop de verificare! nu a fost solicitat in cerinta\n",std1
std1.StergeAbs(2)
#student2
std2=Catalog("George", "Cerc")
std2.IncrAbs() ; std2.IncrAbs() ; std2.IncrAbs() ; std2.IncrAbs()
print "Cu scop de verificare! nu a fost solicitat in cerinta\n",std2
std2.StergeAbs("2")
std2.StergeAbs(2)

#afisare
print std1
print std2
