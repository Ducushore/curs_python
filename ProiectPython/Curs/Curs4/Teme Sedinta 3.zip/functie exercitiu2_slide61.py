# Testeaza cunostinte functii
# Cum realizam o functie
# Ion Studentul

# Creati o functie care afiseze inlocuiasca caracterele de tip spatiu cu underline
# si sa inlocuiasca sirul de caractere "e" cu sirul de caractere "i"
# dintr-un sir de caractere primit ca parametru.
# Verificati ca este sir de caractere inainte de a face aceasta operatie.
# Returnati sirul de caractere modificat sau returnati sirul urmator daca
# nu a fost primit un sir de caracatere:
#                    "Dati va rog 3 un sir de caractere"

# Rulati codul pentru "Merele, perele si pestele nu au E-uri"



def sirCar(a):
    """cere 1 parametru de tip string, returneaza fara E-uri si fara spatii"""
    if(type(a)==type("")):
        a = a.replace("e","i")
        x = a.replace(" ","_")
    else:
        x = "Dati va rog 3 numere"
    return x

print sirCar("Merele, perele si pestele nu au E-uri")
