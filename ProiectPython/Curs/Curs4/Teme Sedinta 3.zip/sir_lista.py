# Tema Sir_lista
# manipularea sir de caractere - lista
# Ion Studentul vers 1

#Creati un program ce imparte sirul de caractere "Avem ce face in Python" intr-o lista. 
#Foloseste lista pentru a prelucra caracterele din interior astfel:
#   -Inlocuieste e cu i
#   -Inlocuieste spatiu cu _ (underline)
#Uneste apoi lista intr-un sir de caractere ce trebuie afisata


sir = "Avem ce face in Python"
lista=[]
sir_final=""

for elem in sir:
    lista+=elem

print lista,"\n"

for elem in lista:
    if (elem=="e"):
        elem="i"
    if (elem==" "):
        elem="_"
    sir_final+=elem

print sir_final

raw_input("Apasa <enter> pt. a iesi")
