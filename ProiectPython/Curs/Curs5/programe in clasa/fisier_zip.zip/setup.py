from distutils.core import setup
import py2exe
#setup file for setup py2exe

setup(console=['c:\MyPyExe.py'])
