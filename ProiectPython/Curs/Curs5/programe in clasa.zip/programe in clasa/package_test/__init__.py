print "Salut Python!"
