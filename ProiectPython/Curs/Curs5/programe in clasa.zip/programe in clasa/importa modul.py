# Program importa modul
# Explica crearea unui modul
# Ion Studentul - 1/26/13

import modul

#returneaza cubul unui numar
print "cubul numarului 3 este :",modul.cub(3)

#vom da argumentele: ratie=1,primul element=3, nr de elemente=5
print "Suma progresiei aritmetice este: ", modul.pa(1,3,5)
#returneaza progresia aritmetica

print modul

raw_input("\n\nApasa <enter> pt a iesi.")
