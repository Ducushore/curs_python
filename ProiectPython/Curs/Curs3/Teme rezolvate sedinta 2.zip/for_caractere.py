# Numarator de caractere
# Demonstreaza functia for
# Ion Stundentul - 1/26/13

#Scrieti un program ce va numara  cate caractere are un sir de caractere dat 
#de utilizator. Aceata numarare sa se realizeze cu ajutorul unui for. La final 
#afisati rezultatul.


sir = raw_input("Scrie un sir!\n")
nr_caractere=0

for caracter in sir:
    nr_caractere+=1
    
print  "Numarul de caractere din sir este",nr_caractere
