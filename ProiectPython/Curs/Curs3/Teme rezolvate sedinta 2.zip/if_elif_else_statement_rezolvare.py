# Manipularea sir caractere  prin if statement
# Demonstreaza  utilizarea sintaxei if
# Ion Studentul 1/13/03

print("\tSalut! \n  Aceasta e un program de verificare sir de caractere")

sir=raw_input("\nScrie te rog un sir de caracatere:\n")

if (sir.isdigit()):
     print "Sirul de caractere este format din numare"
elif (sir.isalpha()):
    print "Sirul de caractere este format din litere"
else:
 print "Sirul de caractere este format din diferite elemente"


raw_input("\n\nApasa <enter> pt a iesi.")

