# TEMA2.2
# Demonstreaza cunostintele acumulate
# Ion Studentul 1/13/03
lista_cumparaturi = {}
cheie=0

meniu =  ''' Tasteaza:
0-Pentru afisare lista de cumparaturi
1 pentru a adauga un element in lista de cumparaturi
2 pentru a sterge un element existent in lista de cumparaturi
3 pentru a sterge lista de cumparaturi
q pentru a iesi
'''


while(True):
    print meniu
    alegere = raw_input('\nTe rog introdu o optiune:\n')
    
    if(alegere == "0"):
        #Afisam lista de cumparaturi
        print "\n"
        for elem in lista_cumparaturi.keys():
            print elem ,"  => ",lista_cumparaturi[elem]
        print "\n"
        if (cheie == 0):
            print "\nLista este goala!\n"
        
    elif(alegere == "1"):
        #Adaugam element in lista de cumparaturi
        val = raw_input('\nTe rog introdu produsul: \n')
        lista_cumparaturi[cheie]=val
        cheie+=1
        
    elif(alegere == "2"):
        #Stergere in element
        cheie_temp = raw_input('\nSpecificati numarul asociat elementului pe care doriti sa-l stergeti: \n')

        #Cheia este un numar deci trebuie sa-l convertesc in integer
        cheie_temp =int(cheie_temp)
        #lista_cumparaturi.keys() returneaza o lista
        if cheie_temp in lista_cumparaturi.keys():
            del lista_cumparaturi[cheie_temp]
        else:
            print "\nNumarul asociat elementului nu este gasit in lista de cumparaturi!\n\
            Va rog reincercati!\n"
    elif(alegere == "3"):
        #Rescriem dictionarul
        lista_cumparaturi = {}
        cheie=0
        print "\nlista a fost stearsa\n"
        
    elif(alegere == "q"):
        break
    else:
        print "Optiunea aleasa nu este valida! \n"


raw_input("\nVa multumim ca ati ales acest program!\n")


