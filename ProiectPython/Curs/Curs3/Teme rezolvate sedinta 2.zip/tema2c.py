# TEMA2.3
# Demonstreaza cunostintele acumulate
# Ion Studentul 1/13/03


## Creati un program cu o lista de CD/DVD-uri utilizand dictionare si liste.
## Trebuie ca programul sa imite lista de cumparaturi prezentata in curs
## (fisierul Lista_avansat.py transmis si pe e-mail) ca si facilitati
## (adaugare, stergere, afisare, iesire din program). Folositi chei numerice incepand de la 0,
## iar valoarea intrarii trebuie sa fie introdusa de utilizator de la tastatura sub meniul adaugare.
## Afisarea dictionarului se va face de forma: key=>Value. 
##Sub Value trebuie sa aveti o lista care sa contina urmatoarele elemente introduse de utilizator: 
##	-Titlu - sir de caractere 
##	-Continut - sir de caractere 
##
##La adaugarea unei intrari noi in dictionar sa se caute prima cheie libera. 
##La afisarea unei intrari a dictionarului creati o afisare pe rand a fiecarui
##element ale listei stocate. 
##Pe langa facilitatile indicate mai sus (adaugare, stergere, afisare, iesire din program)
##adaugati posbilitatea de a cauta o intrare dupa unui sir de caractere dupa Titlu si Continut
##(in acelasi timp implementat prin "or" . 

dic_DVD = {}
cheie=0

meniu =  ''' Tasteaza:
0-Pentru afisare lista de CD/DVD-uri
1 pentru a adauga un element in lista de CD/DVD-uri
2 pentru a sterge un element existent in lista de CD/DVD-uri
3 pentru a sterge lista de CD/DVD-uri
4 pentru a cauta in lista de CD/DVD-uri
q pentru a iesi
'''


while(True):
    print meniu
    alegere = raw_input('\nTe rog introdu o optiune:\n')
    
    if(alegere == "0"):
        #Afisam lista de CD/DVD-uri
        print "\n"
        for elem in dic_DVD.keys():
            print elem ,"  => ",dic_DVD[elem][0],"\n\t",dic_DVD[elem][1]
            # afisam element Titlu si continut
        print "\n"
        if (cheie == 0):
            print "\nLista este goala!\n"
        
    elif(alegere == "1"):
        #Adaugam element in lista de CD/DVD-uri
        val1 = raw_input('\nTe rog introdu Titlul: \n')
        val2 = raw_input('\nTe rog introdu Continut: \n')
        i=0 # utilizat pentru cautarea primului element liber
        while (True):
            if (not dic_DVD.has_key(i)):
                cheie = i
                break
            i+=1
            
        dic_DVD[cheie]=[val1,val2]
        print "\nIntrarea adaugata este:"
        print cheie ,"  => ",dic_DVD[cheie][0],"\n\t",dic_DVD[cheie][1] 
        
    elif(alegere == "2"):
        #Stergere in element
        cheie_temp = raw_input('\nSpecificati numarul asociat elementului pe care doriti sa-l stergeti: \n')

        #Cheia este un numar deci trebuie sa-l convertesc in integer
        if (cheie_temp.isdigit()):
            cheie_temp =int(cheie_temp)
        else:
            cheie_temp = ""
        #dic_DVD.keys() returneaza o lista
        if cheie_temp in dic_DVD.keys():
            del dic_DVD[cheie_temp]
        else:
            print "\nNumarul asociat elementului nu este gasit in lista de cumparaturi!\n\
            Va rog reincercati!\n"
    elif(alegere == "3"):
        #Rescriem dictionarul
        dic_DVD = {}
        cheie=0
        print "\nlista a fost stearsa\n"

    elif(alegere == "4"):
        #Cautam in Dictionar
        cauta = raw_input('\nTe rog introdu un cuvant cautat:\n')
        print "\nCautarea a returnat:"
        i=0 # utilizat daca nu gaseste nimic
        for elem in dic_DVD:
            if((dic_DVD[elem][0].find(cauta)!=-1)or(dic_DVD[elem][1].find(cauta)!=-1)):
                print elem ,"  => ",dic_DVD[elem][0],"\n\t",dic_DVD[elem][1]
                i+=1
        if(i==0):
            print "Nici un rezultat!\n"
        else:
            print "" # cu rol vizual
                  
    elif(alegere == "q"):
        break
    else:
        print "Optiunea aleasa nu este valida! \n"


raw_input("\nVa multumim ca ati ales acest program!\n")


