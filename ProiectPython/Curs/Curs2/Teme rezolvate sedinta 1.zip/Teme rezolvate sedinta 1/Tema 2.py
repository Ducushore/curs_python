# TEMA2
# Demonstreaza cunostintele acumulate
# Ion Studentul 1/13/03

#Creati un program care sa calculeze a si b (variabile capturate de la utilizator prin raw_input)
# in calcularea urmatoarei functii matematice: {6*[2+(a-1)%b]*2a}

a = raw_input("Introduceti primul numar:\n")
a = int(a)

b = raw_input("Introduceti al doilea numar:\n")
b = int(b)

print "raspunsul calculat este: ",(6*(2+(a-1)%b)*2*a)

raw_inpute("\n\nApasa <enter> pt a iesi.")
