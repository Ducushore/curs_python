# Numaratorul
# Demonstreaza functia range() sub for loops
# Ion Stundentul - 1/26/13

print "Numara pana de la 0 la 9:"
for i in range(10):
    print i,

print "\n\nNumara din cinci in cinci pana la 45:"
for i in range(0, 50, 5):
    print i,

print "\n\nNumara invers de la 10 la 1:"
for i in range(10, -2, -1):
    print i,

raw_input("\n\nApasa <enter> pt a iesi.")
